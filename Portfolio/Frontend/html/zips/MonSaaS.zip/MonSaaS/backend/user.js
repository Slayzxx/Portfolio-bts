let users =[]; // stockage temporaire (en mémoire)

function addUser(user){
    users.push(user);
}
function getUsers(){
    return users;
}
 function findUser(email){
    return users.find(u => u.email === email );
 }
 module.exports ={addUser , getUsers, findUser};
