const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const crypto = require('crypto');

const filePath = path.join(__dirname, 'users.json');

// --- LIRE LES UTILISATEURS ---
function getUsers() {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify([], null, 2));
        return [];
    }
    const data = fs.readFileSync(filePath, 'utf-8');
    if (!data) return [];
    return JSON.parse(data);
}

// --- SAUVEGARDER LES UTILISATEURS ---
function saveUsers(usersList) {
    if (!usersList) return; 
    fs.writeFileSync(filePath, JSON.stringify(usersList, null, 2));
}

// --- FONCTION INTERNE POUR ÉVITER LA RÉPÉTITION (VERSION HYBRIDE) ---
// Cette fonction est le cœur de la correction : elle cherche par email OU username
function findUserInList(list, id) {
    if (!id) return null;
    const cleanId = id.toLowerCase().trim();
    return list.find(u => 
        (u.email && u.email.toLowerCase().trim() === cleanId) || 
        (u.username && u.username.toLowerCase().trim() === cleanId)
    ) || null;
}

// --- AJOUTER DES UTILISATEURS ---
function addUser(name, email, password, role, profilePic) {
    const users = getUsers();
    
    if (findUserInList(users, email)) {
        return false;
    }

    const hashedPassword = bcrypt.hashSync(password, 10);
    const verificationToken = crypto.randomBytes(20).toString('hex');
    const shouldBeVerified = (role === 'adminservice' || role === 'owner');

    users.push({
        name,
        email: email.toLowerCase().trim(),
        username: (role === 'adminservice' || role === 'owner') ? email.toLowerCase().trim() : null,
        password: hashedPassword,
        role,
        profilePic: profilePic || null,
        twoFactorEnabled: false,
        isVerified: shouldBeVerified,
        verificationToken: shouldBeVerified ? null : verificationToken
    });
    
    saveUsers(users);
    return shouldBeVerified ? true : verificationToken; 
}

// --- TROUVER UN UTILISATEUR ---
function findUser(id) {
    if (!id) return null;
    const users = getUsers();
    return findUserInList(users, id);
}

// --- ENREGISTRER LE CODE DE RÉINITIALISATION ---
function setResetCode(email, code) {
    const users = getUsers();
    const user = findUserInList(users, email);
    if (user) {
        user.resetCode = code;
        saveUsers(users);
        return true;
    }
    return false;
}

// --- SUPPRIMER UN COMPTE ---
function deleteUser(email, password) {
    const users = getUsers();
    const user = findUserInList(users, email);

    if (!user) {
        return { success: false, message: "Utilisateur introuvable" };
    }

    if (!bcrypt.compareSync(password, user.password)) {
        return { success: false, message: "Mot de passe incorrect" };
    }

    const index = users.indexOf(user);
    users.splice(index, 1);
    saveUsers(users);
    return { success: true, message: "Utilisateur supprimé avec succès" };
}

// --- METTRE À JOUR LA PHOTO DE PROFIL ---
function updateUserPdp(email, newFilename) {
    const users = getUsers();
    const user = findUserInList(users, email);

    if (user) {
        user.profilePic = newFilename;
        saveUsers(users);
        return true;
    }
    return false;
}

// --- ACTIVER OU DÉSACTIVER LA 2FA ---
function update2FASettings(email, enabled) {
    const users = getUsers();
    const user = findUserInList(users, email);
    if (user) {
        user.twoFactorEnabled = enabled;
        saveUsers(users);
        return true;
    }
    return false;
}

// --- ENREGISTRER LE CODE 2FA ---
function set2FACode(email, code) {
    const users = getUsers(); 
    const user = findUserInList(users, email);

    if (user) {
        user.tempCode = String(code); 
        user.codeExpires = Date.now() + 600000; // 10 minutes
        saveUsers(users);
        return true;
    }
    return false;
}

// --- VÉRIFIER LE CODE 2FA ---
function verify2FACode(email, code) {
    const users = getUsers();
    const user = findUserInList(users, email);
    
    if (!user || user.tempCode !== code) {
        return { success: false, message: "Code incorrect." };
    }
    if (Date.now() > user.codeExpires) {
        return { success: false, message: "Code expiré." };
    }

    delete user.tempCode;
    delete user.codeExpires;
    saveUsers(users);
    return { success: true };
}

// --- METTRE À JOUR LE MOT DE PASSE ---
function updatePassword(email, newPassword) {
    const users = getUsers();
    const user = findUserInList(users, email);

    if (user) {
        user.password = bcrypt.hashSync(newPassword, 10);
        user.resetCode = null; 
        saveUsers(users);
        return true;
    }
    return false;
}

// --- SESSION UNIQUE : ENREGISTRER L'ID DE SESSION ACTIF ---
function updateSessionId(id, sessionId) {
    const users = getUsers();
    const user = findUserInList(users, id);

    if (user) {
        user.currentSessionId = sessionId;
        saveUsers(users);
        return true;
    }
    return false;
}

// --- METTRE À JOUR LA DERNIÈRE ACTIVITÉ ---
function updateLastActivity(id) {
    const users = getUsers();
    const user = findUserInList(users, id);

    if (user) {
        user.lastActivity = Date.now();
        saveUsers(users); 
        return true;
    }
    return false;
}

module.exports = {
    addUser,
    findUser,
    getUsers,
    deleteUser,
    updateUserPdp,
    updatePassword,
    saveUsers,
    update2FASettings,
    set2FACode,
    verify2FACode,
    setResetCode,
    updateSessionId,
    updateLastActivity
};