// serveur.js

// Modules nécessaires
const express = require('express'); // Framework serveur web
const path = require('path');    // Pour gérer les chemins
const fs = require('fs');      // Pour lire les fichiers
const bcrypt = require('bcrypt');
const session = require('express-session');
// --- AJOUT : Module pour gérer les fichiers (pdp) ---
const multer = require('multer'); 
//--- AJOUT : Module pour gérer les emails
const nodemailer = require('nodemailer');

const userModule = require('./users');
const { connected } = require('process');

// Création du serveur Express
const app = express();

app.use((req, res,next)=>{ console.log("requete recue :", req.method,req.url); next()});

// Définit le port
const PORT = 3000;

// Chemins des dossiers
const frontendPath = path.join("E:/MonSaaS/frontend");
const backendPath = path.join("E:/MonSaaS/backend");
const apiPath = path.join("E:/MonSaaS/api");

// --- CONFIGURATION MAILTRAP ---
const transporter = nodemailer.createTransport({
 host: "sandbox.smtp.mailtrap.io",
 port: 2525,
 auth: {
  user: "81ab276fed2c06", 
  pass: "7e0a13721de21f" 
 }
});

// --- AJOUT : Fonction pour générer un code 2FA à 6 chiffres ---
function generate2FACode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// --- AJOUT : Fonction pour envoyer un email ---
async function envoyerMail(destinataire, sujet, contenuHtml) {
  try {
    await transporter.sendMail({
      from: '"Mon SaaS 🚀" <noreply@monsaas.com>',
      to: destinataire,
      subject: sujet,
      html: contenuHtml
    });
    console.log("Email envoyé avec succès vers Mailtrap !");
  } catch (err) {
    console.error("Erreur d'envoi d'email :", err);
  }
}

// --- CONFIGURATION DE MULTER (Stockage des photos de profil) ---
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(frontendPath, 'uploads');
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // Nom unique : timestamp + extension d'origine
    const uniqueName = Date.now() + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});
const upload = multer({ storage: storage });

//Middleware pour passer le json envoyé par le front
app.use(express.json());

//Configurer les sessions 
app.use(session({
  // Utilise une chaîne longue et aléatoire pour signer le cookie
  secret: 's3cur3_S3ssi0n_K3y_987!#@ZpR', 
  resave: false,
  saveUninitialized: false, // Plus sécurisé : on ne crée pas de session vide
  name: 'SaaS_ID', // On change le nom par défaut (connect.sid) pour plus de discrétion
  cookie: {
    httpOnly: true, // Le JS du front ne peut pas lire le cookie (protection XSS)
    secure: false,  // Garde à false pour le localhost (HTTP)
    maxAge: 24 * 60 * 60 * 1000, // 24 heures
    sameSite: 'lax' // Protection contre les attaques CSRF
  }
}));

// --- MIDDLEWARE : SESSION UNIQUE ---
app.use((req, res, next) => {
    // 1. Liste des routes publiques (On ne contrôle rien ici)
    const publicRoutes = ['/api/logout', '/api/login', '/api/staff/login', '/api/confirm-email', '/login.html', '/api/owner/login','/staff-entry-99.html'];
    const isAssets = req.path.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico)$/);

    if (publicRoutes.includes(req.path) || isAssets) {
        return next();
    }

    // 2. Si l'utilisateur est connecté
    if (req.session && req.session.user) {
        // IMPORTANT : On cherche par Email OU Username pour être sûr de trouver le PDG
        const identifiant = req.session.user.email || req.session.user.name;
        const userJson = userModule.findUser(identifiant);
        
        if (userJson) {
            // SI KICK (null) OU CHANGEMENT DE SESSION
            // On ajoute une exception : si currentSessionId est null, on force la déconnexion
            if (userJson.currentSessionId === null || (userJson.currentSessionId && req.sessionID !== userJson.currentSessionId)) {
                console.log(`[EXPULSION] Session invalide ou KICK pour : ${identifiant}`);
                
                return req.session.destroy(() => {
                    res.clearCookie("SaaS_ID");
                    if (req.path.startsWith('/api/')) {
                        return res.status(401).json({ message: "Votre session a été terminée." });
                    }
                    return res.redirect('/login.html?reason=kicked');
                });
            }
            // Si OK, on met à jour l'activité
            userModule.updateLastActivity(identifiant);
        }
    }
    next();
});

app.get('/support.html', (req, res, next) => {
  // L'Owner a maintenant le droit de voir cette page sans erreur 403
  if (req.session.user && (req.session.user.role === 'adminservice' || req.session.user.role === 'owner')) {
    next(); 
  } else {
    res.status(403).send("Tu n'as pas les droits pour être ici.");
  }
});

// Middleware pour servir le frontend (DÉPLACÉ APRÈS LES VERROUS)
app.use(express.static(frontendPath));

// --- AJOUT : Rendre le dossier des images par défaut (.jpg) accessible ---
app.use('/img', express.static(path.join(frontendPath, 'img')));

// --- AJOUT : Rendre le dossier des photos de profil accessibles publiquement ---
app.use('/uploads', express.static(path.join(frontendPath, 'uploads')));

// On l'applique à toutes les routes API sensibles
app.use('/api', (req, res, next) => {
  if (req.session && req.session.user) {
    const user = userModule.findUser(req.session.user.email);
    
    // Si l'ID de session actuel (le badge) ne correspond plus à celui du JSON (le registre)
    if (user && user.currentSessionId && req.sessionID !== user.currentSessionId) {
      console.log(`[LOGOUT FORCÉ] ${user.email} s'est connecté ailleurs.`);
      
      return req.session.destroy(() => {
        res.clearCookie("SaaS_ID");
        return res.status(401).json({ 
          message: "Déconnexion : Votre compte est utilisé sur un autre appareil." 
        });
      });
    }
  }
  next();
});

// Test : lister les fichiers du backend et api
fs.readdir(backendPath, (err, files) => {
 if (err) console.error("Erreur backend:", err);
 else console.log("Fichiers backend:", files);
});

fs.readdir(apiPath, (err, files) => {
 if (err) console.error("Erreur API:", err);
 else console.log("Fichiers API:", files);
});

//Redirection selon la session
app.get('/', (req, res)=> {
 res.sendFile(path.join(frontendPath, 'index.html'));
});

//Inscription de compte 
// --- MODIFICATION : Ajout de upload.single('profilePic') ---
app.post('/api/register', upload.single('profilePic'), async (req, res) => {
  console.log("Requête reçue :", req.body);
  const { name, email, password } = req.body; // Sécurisé : on ignore le role envoyé par le front
  const profilePic = req.file ? req.file.filename : null;
    const role = 'user'; // On force le role user

  if (!name || !email || !password) {
    return res.status(400).json({ message: "Données manquantes !" });
  }

  // addUser retourne maintenant le token (string) ou false
  const token = userModule.addUser(name, email, password, role, profilePic);

  if (!token) {
    return res.status(400).json({ message: "Utilisateur déjà existant" });
  }

  // --- ENVOI DE L'EMAIL DE CONFIRMATION ---
  try {
    const confirmUrl = `http://localhost:3000/api/confirm-email?token=${token}`;

    await transporter.sendMail({
      from: '"Mon SaaS" <no-reply@monsaas.com>',
      to: email,
      subject: "Vérifiez votre adresse email",
      html: `
        <div style="font-family: sans-serif; text-align: center; border: 1px solid #eee; padding: 20px;">
          <h2 style="color: #333;">Bienvenue ${name} !</h2>
          <p>Merci de vous être inscrit. Cliquez sur le bouton ci-dessous pour activer votre compte :</p>
          <a href="${confirmUrl}" 
            style="display: inline-block; background-color: #ff0000; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; font-weight: bold; margin-top: 15px;">
            Vérifier mon compte
          </a>
          <p style="font-size: 12px; color: #777; margin-top: 25px;">
            Si le bouton ne fonctionne pas, copiez ce lien : <br> ${confirmUrl}
          </p>
        </div>
      `
    });

    res.json({ message: "Inscription réussie ! Veuillez vérifier vos emails pour activer votre compte." });
  } catch (error) {
    console.error("Erreur email:", error);
    res.status(500).json({ message: "Utilisateur créé, mais erreur lors de l'envoi de l'email." });
  }
});
//Connexion au compte (MODIFIÉE POUR 2FA HYBRIDE)
// Connexion au compte (MODIFIÉE POUR 2FA HYBRIDE + FIX KICK)
app.post('/api/login', express.json(), async (req, res) => {
    const { email, password } = req.body;
    const searchKey = email ? email.toLowerCase().trim() : "";

    const allUsers = userModule.getUsers();
    // Recherche hybride Email ou Username
    const foundUser = allUsers.find(u => 
        (u.email && u.email.toLowerCase() === searchKey) || 
        (u.username && u.username.toLowerCase() === searchKey)
    );

    if (!foundUser) 
        return res.status(400).json({ message: "Identifiant incorrect" });

    const isValidPassword = bcrypt.compareSync(password, foundUser.password);
    if (!isValidPassword)
        return res.status(400).json({ message: "Mot de passe incorrect !" });

    if (foundUser.twoFactorEnabled) {
        const code2FA = generate2FACode();
        userModule.set2FACode(foundUser.email, code2FA);
        // ... (ton code envoi mail)
        return res.json({ requires2FA: true, email: foundUser.email });
    }

    req.session.regenerate((err) => {
        if (err) return res.status(500).json({ message: "Erreur session" });

        req.session.user = {
            name: foundUser.username || foundUser.name,
            email: foundUser.email,
            role: foundUser.role,
            profilePic: foundUser.profilePic
        };

        // ON ÉCRASE LE NULL DU KICK ICI
        userModule.updateSessionId(foundUser.email || foundUser.username, req.sessionID); 

        res.json({ message: "Connexion réussie !", user: req.session.user });
    });
});

// --- AJOUT : Route pour valider le code 2FA ---
app.post('/api/verify-2fa', express.json(), (req, res) => {
  const { email, code } = req.body;
  const result = userModule.verify2FACode(email, code);

  if (result.success) {
    const foundUser = userModule.findUser(email);

    // --- SÉCURISATION : On change l'ID de session après validation du code ---
    req.session.regenerate((err) => {
      if (err) {
        console.error("Erreur session 2FA:", err);
        return res.status(500).json({ message: "Erreur technique de session" });
      }

      // On remplit la nouvelle session propre
      req.session.user = {
        name: foundUser.name,
        email: foundUser.email,
        role: foundUser.role,
        profilePic: foundUser.profilePic
      };

      // --- AJOUT SESSION UNIQUE : On verrouille ce nouvel ID comme le seul valide ---
      // On enregistre req.sessionID dans le JSON de l'utilisateur
      userModule.updateSessionId(foundUser.email, req.sessionID);

      console.log(`2FA Validée - Session sécurisée pour : ${foundUser.email}`);
      
      return res.json({ 
        message: "Vérification réussie !", 
        user: req.session.user 
      });
    });
  } else {
    return res.status(400).json({ message: result.message });
  }
});


// --- AJOUT : Route pour Activer/Désactiver la 2FA ---
app.post('/api/toggle-2fa', express.json(), (req, res) => {
  // 1. Vérifier si l'utilisateur est connecté
  if (!req.session.user) {
    return res.status(401).json({ message: "Non connecté" });
  }

  const { enabled } = req.body;
  const userEmail = req.session.user.email;

  // 2. Aller chercher les infos fraîches de l'utilisateur dans le JSON
  const user = userModule.findUser(userEmail);

  if (!user) {
    return res.status(404).json({ message: "Utilisateur introuvable." });
  }

  // --- NOUVELLE SÉCURITÉ ---
  // Si l'utilisateur veut ACTIVER (enabled === true) mais n'est pas vérifié
  if (enabled && user.isVerified !== true) {
    return res.status(403).json({ 
      message: "Action refusée : Vous devez d'abord vérifier votre adresse email." 
    });
  }

  // 3. Si tout est OK, on procède à la mise à jour
  const success = userModule.update2FASettings(userEmail, enabled);
  
  if (success) {
    // Optionnel : Mettre à jour la session pour refléter le changement immédiatement
    req.session.user.twoFactorEnabled = enabled; 
    res.json({ message: `Le 2FA a été ${enabled ? 'activé' : 'désactivé'} !` });
  } else {
    res.status(500).json({ message: "Erreur lors de la mise à jour." });
  }
});

app.post('/api/resend-verification', async (req, res) => {
  const { email } = req.body;
  const users = userModule.getUsers();
  const user = userModule.findUser(email);

  // On vérifie que l'utilisateur existe et n'est pas déjà vérifié
  if (user && user.isVerified === false) {
    // On récupère son token actuel (ou on en génère un nouveau)
    const token = user.verificationToken; 
    const confirmUrl = `http://localhost:3000/api/confirm-email?token=${token}`;

    try {
      await transporter.sendMail({
        from: '"Mon SaaS" <no-reply@monsaas.com>',
        to: email,
        subject: "Renvoi : Activez votre compte",
        html: `
          <div style="font-family: sans-serif; text-align: center;">
            <h2>Lien de vérification</h2>
            <p>Voici le nouveau lien pour activer votre compte :</p>
            <a href="${confirmUrl}" style="background: red; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
              Vérifier mon compte
            </a>
          </div>
        `
      });
      res.json({ message: "Un nouvel email a été envoyé !" });
    } catch (err) {
      res.status(500).json({ message: "Erreur lors de l'envoi de l'email." });
    }
  } else {
    res.status(400).json({ message: "Utilisateur déjà vérifié ou introuvable." });
  }
});

//Lire la session
app.get('/api/me', (req, res) => {
 if (!req.session.user) {
  return res.json({ loggedIn: false });
 }

 // On va chercher les données en temps réel dans le fichier JSON
 const foundUser = userModule.findUser(req.session.user.email);

 if (!foundUser) {
  return res.json({ loggedIn: false });
 }

 res.json({
  loggedIn: true,
  user: {
   name: foundUser.name,
   email: foundUser.email,
   role: foundUser.role,
   profilePic: foundUser.profilePic,
   twoFactorEnabled: foundUser.twoFactorEnabled || false,
   isVerified: foundUser.isVerified 
  }
 });
});

//Supprimer un compte
app.post('/api/delete-account', express.json(), (req, res) => {
 if (!req.session.user) {
  return res.status(401).json({ message: "Utilisateur non connecté !" });
 }

 const { password } = req.body;
 const foundUser = userModule.findUser(req.session.user.email);

 if (!foundUser) {
  return res.status(400).json({ message: "Utilisateur introuvable !" });
 }

 // --- NOUVELLE SÉCURITÉ : Vérification du statut de l'email ---
 if (foundUser.isVerified === false) {
  return res.status(403).json({ 
   message: "Action impossible : Votre adresse email doit être vérifiée pour supprimer le compte." 
  });
 }

 // Si l'email est vérifié, on continue la logique habituelle
 const result = userModule.deleteUser(foundUser.email, password);
 
 if (!result.success) {
  return res.status(400).json({ message: result.message });
 }

 req.session.destroy(err => {
  if (err) console.error("Erreur lors de la destruction de la session :", err);
 });

 return res.json({ message: result.message });
});

//Se déconnecter
app.post('/api/logout', (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ message: "Utilisateur non connecté" });
  }

  // 1. On récupère l'identifiant pour nettoyer le JSON
  const identifiant = req.session.user.email || req.session.user.name;

  // 2. On met à jour le JSON : l'utilisateur n'a plus de session active
  // Cela fait passer le point au GRIS instantanément dans le panel admin
  userModule.updateSessionId(identifiant, null);

  // 3. On détruit la session serveur
  req.session.destroy(err => {
    if (err) {
      console.error("Erreur logout :", err);
      return res.status(500).json({ message: "Erreur lors de la déconnexion" });
    }

    // 4. On supprime le BON cookie (celui que tu as nommé SaaS_ID)
    res.clearCookie("SaaS_ID"); 
    
    return res.json({ message: "Déconnexion réussie" });
  });
});

// --- AJOUT : Route pour mettre à jour la photo de profil ---
app.post('/api/update-pdp', upload.single('profilePic'), (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ message: "Vous n'êtes pas connecté !" });
  }
  if (!req.file) {
    return res.status(400).json({ message: "Aucun fichier reçu." });
  }
  const newFilename = req.file.filename;
  const success = userModule.updateUserPdp(req.session.user.email, newFilename);

  if (success) {
    req.session.user.profilePic = newFilename;
    return res.json({ message: "Photo mise à jour !", filename: newFilename });
  } else {
    return res.status(500).json({ message: "Erreur lors de l'enregistrement." });
  }
});

// ==========================================
// SECTION MOT DE PASSE OUBLIÉ (CORRIGÉE)
// ==========================================

// --- 1. DEMANDE DE RÉINITIALISATION (ENVOI DU CODE) ---
app.post('/api/forgot-password', async (req, res) => {
  // Nettoyage de l'email
  const emailRecu = req.body.email ? req.body.email.toLowerCase().trim() : "";
  
  // On génère le code
  const resetCode = Math.floor(100000 + Math.random() * 900000).toString();

  // --- CORRECTION : On utilise la nouvelle fonction du module ---
  // Elle va lire le JSON, ajouter le code, et sauvegarder d'un coup.
  const success = userModule.setResetCode(emailRecu, resetCode);

  if (!success) {
    return res.status(404).json({ message: "Email non trouvé." });
  }

  console.log(`[FORGOT] Code ${resetCode} enregistré pour ${emailRecu}`);

  try {
    await transporter.sendMail({
      from: '"Sécurité Mon SaaS" <no-reply@monsaas.com>',
      to: emailRecu,
      subject: "Votre code de récupération",
      html: `<h3>Récupération de mot de passe</h3>
          <p>Voici votre code de vérification : <b>${resetCode}</b></p>`
    });
    res.json({ message: "Code envoyé par email !" });
  } catch (error) {
    console.error("Erreur SMTP:", error);
    res.status(500).json({ message: "Erreur lors de l'envoi de l'email." });
  }
});

// --- 2. VALIDATION DU CODE ET CHANGEMENT DE MOT DE PASSE ---
app.post('/api/reset-password', async (req, res) => {
  const email = req.body.email ? req.body.email.trim().toLowerCase() : "";
  const { code, newPassword } = req.body;
  
  const user = userModule.findUser(email);

  if (!user || !user.resetCode || String(user.resetCode) !== String(code)) {
    return res.status(400).json({ message: "Code invalide ou expiré." });
  }

  const updateSuccess = userModule.updatePassword(email, newPassword);

  if (updateSuccess) {
    console.log(`[SUCCESS] Mot de passe mis à jour pour ${email}`);

    // --- ENVOI DE L'EMAIL DE CONFIRMATION ---
    try {
      await transporter.sendMail({
        from: '"Sécurité Mon SaaS" <no-reply@monsaas.com>',
        to: email,
        subject: "Votre mot de passe a été modifié",
        html: `
          <div style="font-family: sans-serif; line-height: 1.6;">
            <h2 style="color: #4CAF50;">Sécurité de votre compte</h2>
            <p>Bonjour,</p>
            <p>Nous vous informons que le mot de passe de votre compte <strong>${email}</strong> a été modifié avec succès.</p>
            <p>Si vous n'êtes pas à l'origine de cette modification, veuillez contacter notre support immédiatement ou réinitialiser votre mot de passe à nouveau.</p>
            <br>
            <p style="font-size: 12px; color: #666;">Ceci est un message automatique, merci de ne pas y répondre.</p>
          </div>
        `
      });
      console.log(`[MAIL] Confirmation de reset envoyée à ${email}`);
    } catch (mailError) {
      // On ne bloque pas la réponse si le mail échoue, car le MDP est déjà changé
      console.error("Erreur envoi mail confirmation:", mailError);
    }

    res.json({ message: "Mot de passe modifié avec succès !" });
  } else {
    res.status(500).json({ message: "Erreur lors de la mise à jour finale." });
  }
});
app.get('/api/confirm-email', (req, res) => {
  const { token } = req.query;
  
  // On récupère tous les utilisateurs
  const users = userModule.getUsers();
  
  // On cherche celui qui a ce token
  const user = users.find(u => u.verificationToken === token);

  if (user) {
    user.isVerified = true;      // On active le compte
    delete user.verificationToken;   // On supprime le token (usage unique)
    userModule.saveUsers(users);    // On sauvegarde le fichier JSON

    // On redirige vers la page de login avec un paramètre pour afficher un succès
    res.redirect('/login.html?verified=true');
  } else {
    res.status(400).send("<h1>Lien invalide ou expiré.</h1>");
  }
});

// Route pour que le support puisse voir TOUS les utilisateurs
// Route pour que le support (ET l'owner) puisse voir TOUS les utilisateurs
app.get('/api/support/utilisateurs', (req, res) => {
    const user = req.session.user;

    // Vérification inclusive : adminservice OR owner
    const isAuthorized = user && (
        user.role === 'adminservice' || 
        user.role === 'owner' || 
        user.isStaff === true
    );

    if (isAuthorized) {
        const listeBrute = userModule.getUsers();
        const maintenant = Date.now();
        const listeSecurisee = listeBrute.map(u => ({
            name: u.username || u.name || "Inconnu",
            email: u.email,
            role: u.role,
            isVerified: u.isVerified,
            enLigne: !!u.currentSessionId && (u.lastActivity && (maintenant - u.lastActivity) < 180000)
        }));
        return res.json(listeSecurisee);
    }

    res.status(403).json({ message: "Accès non autorisé" });
});

// CETTE ROUTE PERMET AU SERVICE CLIENT DE PRENDRE LE CONTRÔLE
app.post('/api/support/action-urgence', (req, res) => {
  // 1. Vérification de sécurité : Autorise 'adminservice' OU 'owner'
  const role = req.session.user ? req.session.user.role : null;
  
  if (!req.session.user || (role !== 'adminservice' && role !== 'owner')) {
    return res.status(403).json({ message: "Accès interdit. Seul le staff peut faire ça." });
  }

  const { targetEmail, action, nouveauMDP } = req.body;
  const users = userModule.getUsers();
  const cible = users.find(u => u.email === targetEmail);

  if (!cible) return res.status(404).json({ message: "Utilisateur introuvable" });

  // --- NOUVELLE ACTION : LE KICK SIMPLE ---
  if (action === 'kick') {
    cible.currentSessionId = null; // On annule son badge de session
    userModule.saveUsers(users);
    console.log(`[KICK] ${targetEmail} a été éjecté.`);
    return res.json({ message: "Utilisateur expulsé avec succès." });
  }

  // --- RESET PASSWORD (Ton code existant) ---
  if (action === 'reset_password') {
    const bcrypt = require('bcrypt');
    cible.password = bcrypt.hashSync(nouveauMDP, 10);
    cible.currentSessionId = null; 
    userModule.saveUsers(users);
    return res.json({ message: "Mot de passe changé et session coupée." });
  }

  // --- DELETE ACCOUNT (Ton code existant) ---
  if (action === 'delete_account') {
    const index = users.findIndex(u => u.email === targetEmail);
    users.splice(index, 1);
    userModule.saveUsers(users);
    return res.json({ message: "Compte supprimé." });
  }
});

// Route réservée au PROPRIÉTAIRE (Toi)
app.post('/api/owner/creer-staff', (req, res) => {
    // 1. Sécurité
    if (!req.session.user || req.session.user.role !== 'owner') {
        return res.status(403).json({ message: "Zone réservée au propriétaire." });
    }

    const { username, password } = req.body;

    // 2. Création (addUser s'occupe maintenant du isVerified: true tout seul)
    const result = userModule.addUser(username, username, password, 'adminservice');

    if (result) {
        res.json({ message: `Compte employé créé avec succès pour : ${username} !` });
    } else {
        res.status(400).json({ message: "Erreur : Ce nom d'utilisateur existe déjà." });
    }
});

//Connexion sécuriser speciale pour l'owner du saas
app.post('/api/owner/login', (req, res) => {
  const { email, password } = req.body;
  const user = userModule.findUser(email); // Ta fonction habituelle

  if (user && bcrypt.compareSync(password, user.password)) {
    // Vérification CRUCIALE : est-ce qu'il est Owner ?
    if (user.role === 'owner') {
      // On crée la session
      req.session.user = { 
        email: user.email, 
        role: user.role, 
        name: user.name 
      };
      
      // On met à jour l'ID de session unique (ton code actuel)
      userModule.updateSessionId(user.email, req.sessionID);
      
      return res.json({ message: "Bienvenue, Maître." });
    } else {
      // C'est un client qui s'est trompé de porte
      console.log(`[ALERTE] Tentative d'accès owner par : ${email}`);
      return res.status(403).json({ message: "Cette porte n'est pas pour vous." });
    }
  }

  res.status(401).json({ message: "Identifiants invalides." });
});

// --- ROUTE LOGIN STAFF (Accès par Username uniquement) ---
app.post('/api/staff/login', (req, res) => {
    const { username, password } = req.body;
    console.log(`[STAFF LOGIN] Tentative pour : "${username}"`);

    const allUsers = userModule.getUsers();
    
    // On cherche l'utilisateur (Minuscules forcées pour éviter les erreurs de frappe)
    const staff = allUsers.find(u => 
        u.username && u.username.toLowerCase() === username.trim().toLowerCase() && 
        (u.role === 'adminservice' || u.role === 'owner')
    );

    if (!staff) {
        console.log(`[STAFF ERROR] Utilisateur non trouvé ou rôle invalide : ${username}`);
        return res.status(401).json({ success: false, message: "Accès refusé." });
    }

    // VÉRIFICATION DU MOT DE PASSE
    const isMatch = bcrypt.compareSync(password, staff.password);
    
    if (isMatch) {
        req.session.regenerate((err) => {
            if (err) return res.status(500).json({ message: "Erreur technique" });

            req.session.user = {
                name: staff.username,
                email: staff.email || staff.username,
                role: staff.role,
                isStaff: true
            };

            // --- RÉPARATION DU KICK ---
            // On remplace le 'null' par le nouvel ID de session AVANT de répondre
            userModule.updateSessionId(staff.email || staff.username, req.sessionID);

            req.session.save((err) => {
                console.log(`[STAFF SUCCESS] PDG connecté ! SessionID mis à jour.`);
                // On renvoie un JSON clair pour que le front-end sache quoi faire
                return res.json({ success: true, message: "Connexion réussie !" });
            });
        });
    } else {
        console.log(`[STAFF ERROR] Mot de passe incorrect pour : ${username}`);
        return res.status(401).json({ success: false, message: "Mot de passe incorrect." });
    }
});

// Route simple pour tester l'API
app.get('/api/test', (req, res) => {
 res.send("API fonctionne !");
});

// Démarrage du serveur
app.listen(PORT, () => {
 console.log(`Serveur démarré sur http://localhost:${PORT}`);
});