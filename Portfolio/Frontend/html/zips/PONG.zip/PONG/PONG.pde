import processing.sound.*;
import java.io.*;
import processing.data.*;

Balle maBalle;
Raquette maRaquette;

float vitesseX = 4;   // mouvement horizontal
float vitesseY = 4;   // mouvement vertical
boolean gameover = false;
int startMillis;  // Moment où le jeu commence
int elapsedMillis;  // Temps écoulé en millisecondes
int minutes = 0 ;
int seconds = 0 ;
int niveau = -1 ;//(niveau 0=debutant niveau 1=moyen 2=expert)
PImage demonEmoji ;
PImage fondEnfer ;
PImage menuFond;
SoundFile rebondMur ;
SoundFile rebondRaquette ; 
SoundFile gameoverSong ;
SoundFile musiqueFond;

// Variables pour la taille de la raquette et de la balle
float raquetteHauteur = 85;  // Hauteur initiale de la raquette
float raquetteLargeur = 20;  // Largeur de la raquette (on ne change pas cette valeur ici)
float balleDiametre = 20;    // Diamètre initial de la balle

float vitesseMax = 20;   // vitesse maximale autorisée pour éviter que la balle traverse les murs

// ------------------- NOUVEAU -------------------
float menuX = width/2-125;
float menuY = height-150;
float menuLargeur = 250;
float menuHauteur = 80;

int rebondsRaquetteCount = 0; // compteur de rebonds sur la raquette

JSONObject highScores;
int[] highScoresArray = new int[4];
boolean newHighScore = false;
// ------------------- FIN -------------------

void settings() {
  size(700, 600);
  smooth();
  startMillis = millis();  // démarre le compteur lorsque le jeu est lancé
}

void setup() {
  maBalle = new Balle(100, 100, color(255));
  maRaquette = new Raquette(10, 50, color(255));
  textAlign(CENTER, CENTER);
  startMillis = millis();
  demonEmoji = loadImage("demonEmoji.png");  // Charge l'image une seule fois dans setup()
  rebondMur = new SoundFile(this, "bonk.mp3");
  rebondMur.amp(0.3);
  rebondRaquette = new SoundFile( this, "boing2.mp3");
  rebondRaquette.amp(0.6);
  gameoverSong = new SoundFile(this, "gameover.mp3");
  gameoverSong.amp(1.0);
  fondEnfer = loadImage("enfer.png");//background niveau enfer
  musiqueFond = new SoundFile(this, "musiqueFond.mp3");
  musiqueFond.amp(0.5); 
  menuFond = loadImage("menuFond.png");

  // ------------------- High Score -------------------
  try {
    highScores = loadJSONObject("scores.json");  // tente de charger le fichier existant
  } catch(Exception e) {
    highScores = new JSONObject();                // si échec, crée un nouveau fichier
    for (int i = 0; i < 4; i++) {
      highScores.setInt("niveau" + i, 0);
    }
    saveJSONObject(highScores, "scores.json");   // sauvegarde le nouveau fichier
  }

  for (int i = 0; i < 4; i++) {
    if (highScores.hasKey("niveau"+i)) highScoresArray[i] = highScores.getInt("niveau"+i);
    else highScoresArray[i] = 0;
  }
  // ------------------- FIN -------------------
}

void draw() {
  // ---------------- MENU ----------------
  if (niveau == -1){
     // Affiche l'image de fond du menu
     image(menuFond, 0, 0, width, height);
     afficherMenu();
  } else {
    // ---------------- NIVEAUX ----------------
    background(0); // Fond noir par défaut pour tous les niveaux

    // Démarrage de la musique si un niveau est sélectionné et musique non jouée
    if (!musiqueFond.isPlaying() && !gameover) {
      musiqueFond.loop();
    }

    stroke(255);
    if (niveau == 3) {                 
      image(fondEnfer, 0, 0, width, height); // fond enfer
    }
    strokeWeight(4);
    line(width/2, 0, width/2, height);
    noStroke();
    
    // Raquette joueur
    rect(0, mouseY, raquetteLargeur, raquetteHauteur);

    if (!gameover) {
      maBalle.update();   
      maBalle.display();
      
      // Calcul du temps écoulé
      elapsedMillis = millis() - startMillis;  
      minutes = (elapsedMillis / 1000) / 60;   
      seconds = (elapsedMillis / 1000) % 60;   

      // Affichage du temps
      textSize(24);
      fill(255);
      text("Temps : " + minutes + "m " + seconds + "s", width - 120, 30);

      // Affichage compteur de rebonds
      textSize(20);
      fill(255);
      text("Score : " + rebondsRaquetteCount, width - 150, 60);

    } else {
      // ---------------- GAME OVER ----------------
      background(0);
      textSize(32);
      fill(255, 0, 0);
      text("Game Over", width / 2, height / 2);

      textSize(24);
      fill(255);
      text("Temps écoulé : " + minutes + "m " + seconds + "s", width / 2, height / 2 + 40);

      textSize(24);
      fill(255);
      text("Score : " + rebondsRaquetteCount, width / 2, height / 2 + 70);

      textSize(24);
      fill(255);
      text("HighScore: " + highScoresArray[niveau], width / 2, height / 2 + 100);
      if (newHighScore) {
        textSize(20);
        fill(0, 255, 0);
        text("NOUVEAU !", width / 2, height / 2 + 130);
      }

      // Bouton Retour au menu
      menuLargeur = 250;
      menuHauteur = 80;
      menuX = width / 2 - menuLargeur / 2;
      menuY = height / 2 + 160; 
      fill(255, 140, 0);
      rect(menuX, menuY, menuLargeur, menuHauteur);
      fill(255);
      textSize(28);
      text("Retourner au menu", menuX + menuLargeur/2, menuY + menuHauteur/2);
    }
  }
    
  maRaquette.display2();
}

//limite la vitesse de la balle pour empêcher qu’elle dépasse la valeur max
void maxSpeed() {
  if (abs(vitesseX) > vitesseMax) {
    vitesseX = vitesseMax * (vitesseX > 0 ? 1 : -1);  // remet la vitesseX dans la limite max tout en gardant la direction
  }
  if (abs(vitesseY) > vitesseMax) {
    vitesseY = vitesseMax * (vitesseY > 0 ? 1 : -1);  // remet la vitesseY dans la limite max tout en gardant la direction
  }
}

// ------------------- CLASSES -------------------

class Balle {
  float x;
  float y;
  color couleur;

  Balle(float nouvX, float nouvY, color nouvCouleur) {
    x = nouvX;
    y = nouvY;
    couleur = nouvCouleur;
  }

  void update() {
    if (gameover) return; // Ne rien faire si game over

    x += vitesseX;
    y += vitesseY;

    // niveau Moyen selected
    if (niveau == 1) {
      // Rebond haut/bas
      if (y <= 10) {
        y = 10;  
        vitesseY *= -1.1;
        rebondMur.play();
      }
      if (y >= height - 10) {
        y = height - 10;  
        vitesseY *= -1.1;
        rebondMur.play();
      }

      // Rebond sur la raquette
      if (x <= 20 && y >= mouseY && y <= mouseY + raquetteHauteur) {
        x = 20;  
        vitesseX *= -1.1;
        rebondRaquette.play();
        rebondsRaquetteCount++; // compteur de rebonds
      }

      // Rebond côté droit
      if (x >= width - 10) {
        x = width - 10;  
        vitesseX *= -1.1;
        rebondMur.play();
      }

      // Game Over
      if (x <= 10) {
        gameover = true;
        vitesseX = 0;
        vitesseY = 0;
        if (musiqueFond.isPlaying()) {
           musiqueFond.stop();
        }
        gameoverSong.play();
        checkHighScore();
      }
    }

    // niveau débutant selected
    if (niveau == 0) {
      if (y <= 10) {
        y = 10;  
        vitesseY *= -1.;
        rebondMur.play();
      }
      if (y >= height - 10) {
        y = height - 10;  
        vitesseY *= -1.;
        rebondMur.play();
      }

      if (x <= 20 && y >= mouseY && y <= mouseY + raquetteHauteur) {
        x = 20;  
        vitesseX *= -1.;
        rebondRaquette.play();
        rebondsRaquetteCount++; // compteur de rebonds
      }

      if (x >= width - 10) {
        x = width - 10;  
        vitesseX *= -1.;
        rebondMur.play();
      }
      if (x <= 10) {
        gameover = true;
        vitesseX = 0;
        vitesseY = 0;
        if (musiqueFond.isPlaying()) {
            musiqueFond.stop();
        }
        gameoverSong.play();
        checkHighScore();
      }
    }

    // niveau expert selected
    if (niveau == 2) { 
      if (y <= 10) {
        y = 10;  
        vitesseY *= -1.2;
        rebondMur.play();
      }
      if (y >= height - 10) {
        y = height - 10;  
        vitesseY *= -1.2;
        rebondMur.play();
      }

      if (x <= 20 && y >= mouseY && y <= mouseY + raquetteHauteur) {
        x = 20;  
        vitesseX *= -1.2;
        rebondRaquette.play();
        rebondsRaquetteCount++; // compteur de rebonds
      }

      if (x >= width - 10) {
        x = width - 10;  
        vitesseX *= -1.2;
        rebondMur.play();
      }
      if (x <= 10) {
        gameover = true;
        vitesseX = 0;
        vitesseY = 0;
        if (musiqueFond.isPlaying()) {
            musiqueFond.stop();
        }
        gameoverSong.play();
        checkHighScore();
      }
    }

    // niveau enfer selected
    if (niveau == 3) {
      if (y <= 10) {
        y = 10;  
        vitesseY *= -1.5;
        rebondMur.play();
      }
      if (y >= height - 10) {
        y = height - 10;  
        vitesseY *= -1.5;
        rebondMur.play();
      }

      if (x <= 20 && y >= mouseY && y <= mouseY + raquetteHauteur) {
        x = 20;  
        vitesseX *= -1.5;
        rebondRaquette.play();
        rebondsRaquetteCount++; // compteur de rebonds
      }

      if (x >= width - 10) {
        x = width - 10;  
        vitesseX *= -1.5;
        rebondMur.play();
      }
      if (x <= 10) {
        gameover = true;
        vitesseX = 0;
        vitesseY = 0;
         if (musiqueFond.isPlaying()) {
         musiqueFond.stop();
        }
        gameoverSong.play();
        checkHighScore();
      }
    }

    maxSpeed();   // limite la vitesse après les rebonds pour éviter les traversées
  }

  void display() {
    if (gameover) return; // Ne pas afficher si game over
    fill(couleur);
    ellipse(x, y, balleDiametre, balleDiametre);  // Utiliser balleDiametre
  }
}

class Raquette {
  float x;
  float y;
  color couleur;

  Raquette(float nouvX, float nouvY, color nouvCouleur) {
    x = nouvX;
    y = nouvY;
    couleur = nouvCouleur;
  }

  void display2() {
    // Si tu veux afficher une deuxième raquette, active cette ligne
    // fill(couleur);
    // rect(x, y, 20, 85);
  }
}

void afficherMenu() {
   textSize(32);
  fill(255);
  text("Choisir un niveau", width / 2, height / 4);
  
  // Boutons pour sélectionner le niveau
  float btnHauteur = 80; // <-- hauteur des boutons augmentée

  // Débutant
  fill(0, 255, 0);
  rect(width / 2 - 100, height / 2 - 60, 200, btnHauteur);
  fill(0);
  textSize(24);
  text("Débutant", width / 2, height / 2 - 60 + btnHauteur/2);
  textSize(16);
  text("HighScore: " + highScoresArray[0], width / 2, height / 2 - 60 + btnHauteur/2 + 25);

  // Intermédiaire
  fill(255, 255, 0);
  rect(width / 2 - 100, height / 2 + 30, 200, btnHauteur);
  fill(0);
  text("Intermédiaire", width / 2, height / 2 + 30 + btnHauteur/2);
  textSize(16);
  text("HighScore: " + highScoresArray[1], width / 2, height / 2 + 30 + btnHauteur/2 + 25);

  // Avancé
  fill(255, 0, 0);
  rect(width / 2 - 100, height / 2 + 120, 200, btnHauteur);
  fill(0);
  text("Expert", width / 2, height / 2 + 120 + btnHauteur/2);
  textSize(16);
  text("HighScore: " + highScoresArray[2], width / 2, height / 2 + 120 + btnHauteur/2 + 25);

  // Enfer
  fill(139, 0, 0);
  rect(width / 2 - 100, height / 2 + 210, 200, btnHauteur);
  fill(0);
  text("Enfer", width / 2, height / 2 + 210 + btnHauteur/2);
  textSize(16);
  text("HighScore: " + highScoresArray[3], width / 2, height / 2 + 210 + btnHauteur/2 + 25);

  image(demonEmoji, width / 2 + 15, height / 2 + 210 + 40 - 17, 35, 35);
}  

void mousePressed() {
  if (niveau == -1) {
    if (mouseX >= width / 2 - 100 && mouseX <= width / 2 + 100) {
      if (mouseY >= height / 2 - 60 && mouseY <= height / 2 + 20) {
        niveau = 0;  // Débutant
      } else if (mouseY >= height / 2 + 30 && mouseY <= height / 2 + 110) {
        niveau = 1;  // Intermédiaire
      } else if (mouseY >= height / 2 + 120 && mouseY <= height / 2 + 200) {
        niveau = 2;  // Avancé
      } else if (mouseY >= height / 2 + 210 && mouseY <= height / 2 + 290) {
        niveau = 3;  // Enfer
      }
    }
  }

  // ------------------- NOUVEAU -------------------
  // Bouton Back to Menu
  if (gameover) {
    if (mouseX >= menuX && mouseX <= menuX + menuLargeur &&
        mouseY >= menuY && mouseY <= menuY + menuHauteur) {
      gameover = false;
      niveau = -1;  // retour au menu
      vitesseX = 4;
      vitesseY = 4;
      rebondsRaquetteCount = 0; // reset compteur
      startMillis = millis(); 
      newHighScore = false;
    }
  }
  // ------------------- FIN -------------------  
}

void keyPressed() {
  if (key == 'd' || key == 'D') {  // Si l'utilisateur appuie sur "D"
    raquetteHauteur /= 2;    // Diviser la hauteur de la raquette par 2
    balleDiametre /= 2;      // Diviser le diamètre de la balle par 2
  }
  
  if (keyCode == UP) {  // Si l'utilisateur appuie sur la flèche haut
    vitesseX *= 2;  // Doubler la vitesse horizontale de la balle
    vitesseY *=2;  // Doubler la vitsse verticale de la balle
  }
  if(keyCode == DOWN) { //Si le joeur appuie sur fleche du bas vitesse divisé par 2
    vitesseX /= 2; // vitesse horizontale divisé par 2
    vitesseY /= 2; // vitesse verticale divisé par 2
 }
}

// ------------------- HIGH SCORE -------------------
void checkHighScore() {
  if (rebondsRaquetteCount > highScoresArray[niveau]) {
    highScoresArray[niveau] = rebondsRaquetteCount;
    highScores.setInt("niveau"+niveau, rebondsRaquetteCount);
    saveJSONObject(highScores, "scores.json");
    newHighScore = true;
  }
}
// ------------------- FIN -------------------
