// ==========================================
// 1. BASE DE DONNÉES DES INGRÉDIENTS
// ==========================================
const databaseIngredients = {
    // --- TACOS ---
    "tacos-taille-m": "Tacos 1 viande au choix avec frites et sauce fromagère maison.",
    "tacos-taille-l": "Tacos 2 viandes au choix avec frites et sauce fromagère maison.",
    "tacos-taille-xl": "Tacos 3 viandes au choix avec frites et sauce fromagère maison.",
    "tacos-taille-xxl": "Le géant : 4 viandes au choix avec frites et sauce fromagère maison.",

    // --- BURGERS ---
    "cheese-burger": "Pain brioché, steak 45g, cheddar, crudités.",
    "double-cheese-burger": "Pain brioché, 2 steaks 45g, double cheddar, crudités",
    "le-chevre-miel": "Pain brioché, steak 90g, fromage de chèvre, miel, crudités.",
    "chicken-burger": "Pain brioché, 2 tenders, cheddar, crudités.",
    "le-180": "Pain brioché, steak 180g, double cheddar, crudités",
    "burger-maison": "Pain brioché, viande hachée maison 150g, bacon, crudités",
    "le-360": "Double steak 180g (360g de viande), 4 cheddar, crudités",

    // --- SANDWICHS ---
    "kebab": "Pain à kebab, kebab, crudités",
    "americain": "Pain baguette, 2 steaks 45g, cheddar, crudités.",
    "merguez": "Pain baguette, 2 merguez, cheddar, crudités.",
    "cordon-bleu": "Pain baguette, cordon bleu, cheddar, crudités.",
    "chicken-curry": "Pain baguette, poulet curry, cheddar, crudités.",
    "boursin": "Pain baguette, poulet nature, Boursin, crudités.",
    "wrap-tenders": "Galette de blé, tenders, cheddar, crudités",
    "maxi-royal": "Pain baguette, 2 steaks 45g, rösti, oeuf, cheddar",
    "kefta-maison": "Pain baguette, viande hachée maison, cheddar, crudités.",
    "pannini": "Kebab, 4 Fromages, Poulet, Viande hachée, Merguez",


    // --- ASSIETTES ---
    "assiette-kebab": "Kebab, crudités , frite, boulgour.",
    "assiette-royal": "Kebab, poulet, agneau, kefta, merguez",
    "brochette-poulet-ou-merguez": "Poulet ou merguez, salade, frite, boulgour",
    "brochette-agneau": "Brochette d'agneau, crudités, frite, boulgour",
    "kefta-maison-": "Viande hachée maison, cheddar, crudités, frite, boulgour.",

    // --- TEX-MEX ---
    "nuggets-x4": "4 pièces de poulet pané.",
    "nuggets-x6": "6 pièces de poulet pané.",
    "oignon-rings-x4": "4 rondelles d'oignons frits.",
    "oignon-rings-x6": "6 rondelles d'oignons frits.",
    "tenders-x4": "4 filets de poulet panés.",
    "tenders-x6": "6 filets de poulet panés.",
    "wings-x4": "4 ailerons de poulet épicés.",
    "wings-x6": "6 ailerons de poulet épicés.",
    "barquettes-petites-frites": "Petite portion de frites croustillantes.",
    "barquettes-grandes-frites": "Grande portion de frites croustillantes.",
    "barquettes-petites-viandes": "Petite barquette de viande au choix (Kebab, Poulet, Merguez...).",
    "barquettes-grandes-viandes": "Grande barquette de viande généreuse au choix.",
    "barquettes-petites-frites-fromagere": "Petites frites nappées de notre sauce fromagère maison.",
    "barquettes-grandes-frites-fromagere": "Grandes frites nappées de notre sauce fromagère maison.",
    "barquettes-petites-frites-cheddar": "Petites frites avec sauce cheddar fondante.",
    "barquettes-grandes-frites-cheddar": "Grandes frites avec sauce cheddar fondante.",

    // --- FORMULES ---
    "f1": "4 Kebabs + 4 Frites + Boisson 1.25L.",
    "f2": "2 Tacos M + 2 Cheese Burgers + 4 Frites + Boisson 1.25L.",
    "f3": "2 Tacos M + 2 Frites + 2 Boissons 33cl + 2 Tiramisus.",
    "menu-enfant": "Cheese ou 5 Nuggets ou Mini Tacos + Frite + Capri-Sun ou Compote.",
    "menu-etudiant": "Tacos M Kebab ou Nuggets + Boisson 33cl + Frite (Sur présentation de la carte).",

    // --- DESSERTS ---
    "tiramisu-maison": "Tiramisu artisanal fait maison (plusieurs parfums disponibles).",
    "panna-cotta-maison": "Panna Cotta onctueuse faite maison.",
    "cheese-cake": "Gâteau au fromage frais.",
    "tarte-au-daim": "Tarte croquante au chocolat et éclats de caramel.",
    "pannini-nutella": "Pain panini grillé fourré au Nutella.",
    "brownie": "Gâteau fondant au chocolat.",

    // --- BOISSONS ---
    "canette-33cl": "Boisson rafraîchissante au choix (Coca, Fanta, Oasis...).",
    "bouteille-125l": "Bouteille de boisson au choix (1.25L).",
    "bouteille-15l": "Bouteille de boisson au choix (1.5L).",
    "ayran": "Boisson traditionnelle turque à base de yaourt.",
    "eau": "Bouteille d'eau minérale 50cl.",

    // --- SUPPLÉMENTS ---
    "oeuf": "Supplément un œuf.",
    "bacon": "Supplément tranches de bacon.",
    "miel": "Supplément touche de miel.",
    "lardon": "Supplément lardons.",
    "rosti": "Supplément galette de pomme de terre.",
    "cheddar": "Supplément tranche de cheddar.",
    "boursin": "Supplément fromage Boursin.",
    "raclette": "Supplément fromage raclette.",
    "chevre": "Supplément fromage de chèvre.",
    "kiri": "Supplément fromage Kiri.",
    // --- SALADES ---
    "salade-chicken": "Salade, tomate, mais, tenders.",
    "salade-chevre": "Salade, tomate, mais, croutons, chèvre chaud."
};

// ==========================================
// 2. FONCTIONS DE NAVIGATION (VOLETS)
// ==========================================

function ouvrirVolet(id) {
    const volet = document.getElementById(id);
    if (volet) {
        volet.classList.add('active');
        document.body.style.overflow = 'hidden';
    } else {
        console.error("Le volet avec l'ID '" + id + "' n'existe pas dans le HTML.");
    }
}

function fermerVolet(id) {
    const volet = document.getElementById(id);
    if (volet) {
        volet.classList.remove('active');
    }
    setTimeout(() => {
        if (!document.querySelector('.volet.active')) {
            document.body.style.overflow = 'auto';
        }
    }, 10); 
}

// ==========================================
// 3. FONCTION DE DÉTAIL PRODUIT
// ==========================================

function ouvrirDetail(nom, prix) {
    // 1. Remplissage des textes de base
    const titre = document.getElementById('detail-produit-titre');
    const prixElt = document.getElementById('detail-produit-prix');
    const zoneOptions = document.getElementById('zone-options-tacos');
    const imgElt = document.getElementById('detail-produit-image');
    const placeholder = document.getElementById('detail-produit-image-placeholder-text');

    if (titre) titre.innerText = nom;
    if (prixElt) prixElt.innerText = prix;

    // 2. Création de l'ID pour les ingrédients et l'image (ex: "Le 180" -> "le-180")
    const produitId = nom.toLowerCase()
        .trim()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "") 
        .replace(/\s+/g, '-')                               
        .replace(/[^a-z0-9-]/g, '');

    // 3. GESTION DE L'IMAGE
    if (imgElt) {
        // On définit le chemin (assure-toi que tes images sont en .webp)
        const imagePath = `img/plats/${produitId}.webp`;
        imgElt.src = imagePath;

        imgElt.onload = () => {
            imgElt.style.display = "block";
            if (placeholder) placeholder.style.display = "none";
        };

        imgElt.onerror = () => {
            imgElt.style.display = "none";
            if (placeholder) {
                placeholder.style.display = "block";
                placeholder.innerText = "IMAGE BIENTÔT DISPONIBLE";
            }
        };
    }

    // 4. LOGIQUE D'AFFICHAGE DU TEXTE (Ta logique originale)
    const nomNormalise = nom.toLowerCase();

    if (nomNormalise.includes('tacos')) {
        zoneOptions.innerHTML = `
            <div class="detail-options-container" style="text-align:left; margin-top:15px;">
                <div style="display:flex; gap:30px;">
                    <div>
                        <h3 style="color:#D4AF37; font-size:1rem;">🥩 Viandes</h3>
                        <ul style="list-style:none; padding:0; color:#ccc; font-size:0.85rem; line-height:1.5;">
                            <li>Viande Hachée, Nuggets, Kebab</li>
                            <li>Poulet Curry, Tenders, Merguez</li>
                            <li>Cordon Bleu, Kefta(maison)</li>
                        </ul>
                    </div>
                    <div>
                        <h3 style="color:#D4AF37; font-size:1rem;">🥫 Sauces</h3>
                        <ul style="list-style:none; padding:0; color:#ccc; font-size:0.85rem; line-height:1.5;">
                            <li>Blanche, Algérienne, Biggy</li>
                            <li>Harissa, Ketchup, Mayonaise</li>
                        </ul>
                    </div>
                </div>
            </div>`;
    } else {
        const ingredients = databaseIngredients[produitId] || "Préparation maison avec des produits frais.";
        zoneOptions.innerHTML = `
            <div style="text-align:left; margin-top:15px;">
                <h3 style="color:#D4AF37; font-size:1rem; border-left:3px solid #D4AF37; padding-left:10px;">🥗 COMPOSITION</h3>
                <p style="color:#ccc; font-size:0.9rem; margin-top:10px; line-height:1.4;">${ingredients}</p>
            </div>`;
    }

    // 5. Appel de la fonction d'ouverture du volet
    ouvrirVolet('v-detail-produit');
}

function actualiserStatut() {
    const now = new Date();
    const t = now.getHours() + (now.getMinutes() / 60);
    const statusDiv = document.getElementById('status');
    let message = "";

    if (t >= 11 && t <= 14) {
        if (t >= 13.5) { 
            message = '<span style="color:#f1c40f">● FERME BIENTÔT (14H)</span>';
        } else {
            message = '<span style="color:#2ecc71">● OUVERT ACTUELLEMENT</span>';
        }
    } 
    else if (t >= 17.5 && t <= 22) {
        if (t >= 21.5) { 
            message = '<span style="color:#f1c40f">● FERME BIENTÔT (22H)</span>';
        } else {
            message = '<span style="color:#2ecc71">● OUVERT ACTUELLEMENT</span>';
        }
    } 
    else if (t < 11) {
        message = '<span style="color:#e63946">○ FERMÉ - RÉOUVRE À 11H</span>';
    } else if (t > 14 && t < 17.5) {
        message = '<span style="color:#e63946">○ FERMÉ - RÉOUVRE À 17H30</span>';
    } else {
        message = '<span style="color:#e63946">○ FERMÉ - RÉOUVRE DEMAIN</span>';
    }

    if (statusDiv) statusDiv.innerHTML = message;
}

window.onload = () => {
    actualiserStatut();
    setInterval(actualiserStatut, 30000); 
};
//Si l'utilisateur ne possede pas l'app concernée
document.querySelectorAll('.facebook, .instagram, .tiktok, .snapchat').forEach(link => {
    link.addEventListener('click', function(e) {
        const appUrl = this.getAttribute('href');
        let webUrl = "";

        // Définition des liens de secours
        if(this.classList.contains('facebook'))  webUrl = "https://www.facebook.com/kebabgrill36";
        if(this.classList.contains('instagram')) webUrl = "https://www.instagram.com/kebabgrill36";
        if(this.classList.contains('tiktok'))    webUrl = "https://www.tiktok.com/@kebabgrill36";
        if(this.classList.contains('snapchat'))  webUrl = "https://www.snapchat.com/add/kebabgrill36";

        if (appUrl.includes('://')) {
            e.preventDefault();
            window.location.href = appUrl;
            
            // Si l'app ne s'ouvre pas, direction le navigateur
            setTimeout(() => {
                window.location.href = webUrl;
            }, 500);
        }
    });
});